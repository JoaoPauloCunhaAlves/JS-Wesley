let nome = "Joana";

console.log(nome);
console.log (`Meu nome é: ${nome}`)

let laranjas = 5;
console.log(laranjas * laranjas);

nome = "joao"
console.log(nome)

laranjas = 8974;
console.log(laranjas)