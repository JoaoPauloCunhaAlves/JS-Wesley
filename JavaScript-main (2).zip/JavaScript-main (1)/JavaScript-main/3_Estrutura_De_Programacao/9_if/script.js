let idade =18;
if (idade == 18) {
    console.log("A idade é 18");
}
if (idade > 25) {
    console.log("Idade maior que 25");
}
let nome = "Lucas";
if (nome == "Lucas" && idade > 18){
    console.log('Liberado!')
}

let passaporte = false;
if (nome == "Lucas" && idade >30 || passaporte == true) {
    console.log("Liberado 2!")
}