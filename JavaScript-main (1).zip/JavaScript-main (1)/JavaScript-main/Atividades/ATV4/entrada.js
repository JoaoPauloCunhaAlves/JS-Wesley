// (A)
let nome = prompt("Olá, qual seu nome?")

console.log(`Olá, seja bem vindo(a) ${nome}`)

//-----------------------------------------------------------------------------------//

// (B)
let numero1 = Number(prompt("Insira o primeiro número da conta de adição: "))
let numero2 = Number(prompt("Insira o segundo número da conta: "))
let soma = (numero1+numero2)
console.log(`A soma dos número ${soma}`)