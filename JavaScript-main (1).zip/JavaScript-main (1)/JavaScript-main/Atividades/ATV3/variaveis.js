// (A)
let variavel1 = 14;
var variavel2 = 15;
const variavel3 = 16;

variavel1 = 28;
variavel2 = 30;
variavel3 = 32;

console.log(variavel1, variavel2, variavel3)
//-----------------------------------------------------------------------------------//

// (B)

for (i = 0; i < 10; i++){

}
console.log(i)