// (A)
let aleatorio = Math.floor(Math.random() * 100)
console.log(aleatorio)

// (B)
let num = Number(prompt("Insira um número para descobrir a raiz: "))
console.log(Math.sqrt(num))