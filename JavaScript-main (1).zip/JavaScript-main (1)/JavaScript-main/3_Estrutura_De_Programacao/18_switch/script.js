let nome = "Lanche";
let esc = prompt("escolha algo do cardapio");
switch (esc) {
    case "Lanche":
    console.log("Lanche");
    break;
    case "Bolo":
    console.log("Bolo escolhido");
    break;
    default:
    console.log("Não sei");
    break;
}