let nome = prompt("Qual seu nome ?");
console.log(nome)
