let nome = "Juca";
let idade = 28;

if (nome != undefined && nome == "Joaquim"){
    console.log("nome esta definido!");
} else if (nome != undefined && nome.length > 5 && idade == 50){
    console.log("Meu nome é Juca");
} else {
    console.log("Não é o Juca")
}