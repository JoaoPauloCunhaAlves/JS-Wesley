console.log(typeof 'Oi, meu nome é kelvin');
console.log(typeof 'Quero uma porsche');
console.log(typeof 'Teste');
console.log(typeof 'infinity');



