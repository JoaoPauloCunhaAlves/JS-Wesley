function imprimirNoConsole(){
    console.log('Olá turma')
}
imprimirNoConsole();

function imprimirNumero(num) {
    console.log('O numero é =' + num)
}
imprimirNumero(5);


function somaNumero(sum1, sum2) {
    console.log(Number(sum1) + Number(sum2))
}
somaNumero(3,9);


const numeroAleatorio = function () {
    console.log(Math.random());
};
numeroAleatorio();

function multiplicacao (num1,num2,num3) {
    return num1*num2*num3
}
console.log(multiplicacao(3,6,6))
