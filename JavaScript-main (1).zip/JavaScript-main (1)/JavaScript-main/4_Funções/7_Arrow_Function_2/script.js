const multiplicarPorDois = (x) => {
    return x * 2;
};
console.log(multiplicarPorDois(5));

const multiplicarPorDois2 = (x) => x * 2;
console.log(multiplicarPorDois2(4))