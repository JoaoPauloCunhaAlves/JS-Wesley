function multiplicacao (num1,num2,num3) {
    return num1*num2*num3
}
console.log(multiplicacao(3,6,6))


function podeDirigir(idade, cnh){
    if(idade >= 18 && cnh == true) {
        console.log('Pode dirigir')
    } else {
        console.log('Nao pode dirigir')
    }
}
console.log(podeDirigir(19, true));
console.log(podeDirigir(12, false));
console.log(podeDirigir(21, false));