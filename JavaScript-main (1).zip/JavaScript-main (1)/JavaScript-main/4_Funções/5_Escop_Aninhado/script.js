let a = 10;

function multiplicar(x, y){
    let a = x * y
    if (a > 10){
        let a = 0;
        a++
        console.log('Dentro do if ' + a);
    }
    console.log('Dentro da Função ' + a);
}
console.log('Fora de tudo ' + a);
multiplicar(5, 6)